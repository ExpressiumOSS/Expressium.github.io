using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace Expressium.Coffeeshop.Web.Controls
{
    public static class WebElements
    {
        public static int ElementTimeout { get; set; }

        public static bool Highlight { get; set; }
        public static int HighlightTimeout { get; set; }
        public static int HighlightWidth { get; set; }
        public static string HighlightStyle { get; set; }
        public static string HighlightActionColor { get; set; }
        public static string HighlightValidationColor { get; set; }
        public static string HighlightFailureColor { get; set; }

        static WebElements()
        {
            ElementTimeout = 10000;

            Highlight = false;
            HighlightTimeout = 250;
            HighlightWidth = 2;
            HighlightStyle = "dashed";
            HighlightActionColor = "orange";
            HighlightValidationColor = "mediumseagreen";
            HighlightFailureColor = "darkred";
        }

        public static bool IsPresent(this By locator, IWebDriver driver)
        {
            try
            {
                driver.FindElement(locator);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static void HighlightAction(this IWebElement element, IWebDriver driver)
        {
            if (Highlight)
                HighlightElement(element, driver, HighlightWidth, HighlightStyle, HighlightActionColor);
        }

        public static void HighlightValidation(this IWebElement element, IWebDriver driver)
        {
            if (Highlight)
                HighlightElement(element, driver, HighlightWidth, HighlightStyle, HighlightValidationColor);
        }

        public static void HighlightFailure(this IWebElement element, IWebDriver driver)
        {
            if (Highlight)
                HighlightElement(element, driver, HighlightWidth, HighlightStyle, HighlightFailureColor);
        }

        public static void HighlightClear(this IWebElement element, IWebDriver driver)
        {
            if (Highlight)
            {
                Thread.Sleep(HighlightTimeout);
                HighlightElement(element, driver, 0, HighlightStyle, HighlightFailureColor);
            }
        }

        private static void HighlightElement(this IWebElement element, IWebDriver driver, int width, string style, string color)
        {
            try
            {
                var javaScriptExecuter = (IJavaScriptExecutor)driver;
                var attribute = element.GetDomProperty("style");
                attribute += $"; outline: {width}px {style} {color}; outline-offset: -1px;";
                javaScriptExecuter.ExecuteScript("arguments[0].setAttribute('style', arguments[1]);", element, attribute);
            }
            catch
            {
            }
        }

        public static void WaitForElementIsVisible(this IWebElement element, IWebDriver driver)
        {
            try
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(ElementTimeout));
                wait.Until(WebConditions.ElementIsVisible(element));
            }
            catch
            {
                throw new ApplicationException($"Page element was expected to be visible within {ElementTimeout} milliseconds...");
            }
        }

        public static void WaitForElementIsEnabled(this IWebElement element, IWebDriver driver)
        {
            try
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(ElementTimeout));
                wait.Until(WebConditions.ElementIsEnabled(element));
            }
            catch
            {
                throw new ApplicationException($"Page element was expected to be enabled within {ElementTimeout} milliseconds...");
            }
        }

        public static void WaitForElementIsInvisible(this By locator, IWebDriver driver, int initialTimeout, int timeout)
        {
            try
            {
                Thread.Sleep(initialTimeout);
                var wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(timeout));
                wait.Until(WebConditions.ElementIsInvisible(locator));
            }
            catch
            {
                throw new ApplicationException($"Page element '{locator}' was expected to be invisible within {timeout} milliseconds...");
            }
        }

        public static void WaitForElementIsInvisible(this IWebElement element, IWebDriver driver, int initialTimeout, int timeout)
        {
            try
            {
                Thread.Sleep(initialTimeout);
                var wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(timeout));
                wait.Until(WebConditions.ElementIsInvisible(element));
            }
            catch
            {
                throw new ApplicationException($"Page element was expected to be invisible within {timeout} milliseconds...");
            }
        }

        public static void WaitForSelectOptionIsPopulated(this SelectElement element, IWebDriver driver, string value)
        {
            try
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(ElementTimeout));
                wait.Until(WebConditions.SelectOptionIsPopulated(element, value));
            }
            catch
            {
                throw new ApplicationException($"Page element option '{value}' was expected to be populated within {ElementTimeout} milliseconds...");
            }
        }

        public static void ScrollIntoViewUp(this IWebElement element, IWebDriver driver)
        {
            var javaScriptExecutor = (IJavaScriptExecutor)driver;
            javaScriptExecutor.ExecuteScript("arguments[0].scrollIntoView(false);", element);
        }

        public static void ScrollIntoViewDown(this IWebElement element, IWebDriver driver)
        {
            var javaScriptExecutor = (IJavaScriptExecutor)driver;
            javaScriptExecutor.ExecuteScript("arguments[0].scrollIntoView(true);", element);
        }

        public static void MoveToElement(this IWebElement element, IWebDriver driver)
        {
            var actions = new Actions(driver);
            actions.MoveToElement(element).Build().Perform();
        }

        public static void ClickElementDoubleClick(this IWebElement element, IWebDriver driver)
        {
            var actions = new Actions(driver);
            actions.DoubleClick(element).Perform();
        }

        public static void ClickElementContextMenu(this IWebElement element, IWebDriver driver)
        {
            var actions = new Actions(driver);
            actions.ContextClick(element).Perform();
        }

        public static IWebElement GetElement(this By locator, IWebDriver driver)
        {
            try
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(ElementTimeout));
                return wait.Until(WebConditions.ElementExists(locator));
            }
            catch
            {
                throw new ApplicationException($"Page element '{locator}' was expected to exist within {ElementTimeout} milliseconds...");
            }
        }

        public static IWebElement GetChildElement(this By locator, IWebDriver driver, By childLocator)
        {
            try
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(ElementTimeout));
                return wait.Until(_ => driver.FindElement(locator).FindElement(childLocator));
            }
            catch
            {
                throw new ApplicationException($"Page child element '{childLocator}' was expected to be found within {ElementTimeout} milliseconds...");
            }
        }

        public static List<IWebElement> GetChildElements(this By locator, IWebDriver driver, By childLocator)
        {
            try
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(ElementTimeout));
                return wait.Until(_ => driver.FindElement(locator).FindElements(childLocator).ToList());
            }
            catch
            {
                throw new ApplicationException($"Page child element '{childLocator}' was expected to be found within {ElementTimeout} milliseconds...");
            }
        }
    }
}
