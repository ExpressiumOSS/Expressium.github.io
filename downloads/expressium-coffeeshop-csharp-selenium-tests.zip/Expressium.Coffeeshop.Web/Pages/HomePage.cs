using OpenQA.Selenium;
using Expressium.Coffeeshop.Web.Controls;
using System;
using System.Collections.Generic;
using log4net;

namespace Expressium.Coffeeshop.Web.Pages
{
    public partial class HomePage : BasePage
    {
        private WebControl Heading => new WebControl(driver, By.XPath("//h1[text()]"));

        public HomePage(ILog logger, IWebDriver driver) : base(logger, driver)
        {

            WaitForPageTitleEquals("Home");
            WaitForPageElementIsVisible(Heading);
        }

        #region Extensions

        #endregion
    }
}
