using Expressium.Coffeeshop.Web.Controls;
using log4net;
using OpenQA.Selenium;

namespace Expressium.Coffeeshop.Web.Pages
{
    public class BaseTable : BasePage
    {
        protected readonly WebTable baseControl;

        public BaseTable(ILog logger, IWebDriver driver, By baseLocator) : base(logger, driver)
        {
            baseControl = new WebTable(driver, baseLocator);
        }

        public virtual int GetNumberOfRows()
        {
            logger.Info("GetNumberOfRows()");
            return baseControl.GetNumberOfRows();
        }

        public virtual int GetNumberOfColumns()
        {
            logger.Info("GetNumberOfColumns()");
            return baseControl.GetNumberOfColumns();
        }

        public virtual void ClickCell(object rowId, object columnId)
        {
            logger.Info($"ClickCell({rowId}, {columnId})");
            baseControl.ClickCell(rowId, columnId);
        }

        public virtual void SetCellTextBox(object rowId, object columnId, string value)
        {
            logger.Info($"SetCellTextBox({rowId}, {columnId})");
            baseControl.SetCellTextBox(rowId, columnId, value);
        }

        public virtual string GetCellTextBox(object rowId, object columnId)
        {
            logger.Info($"GetCellTextBox({rowId}, {columnId})");
            return baseControl.GetCellTextBox(rowId, columnId);
        }

        public virtual void SetCellCheckBox(object rowId, object columnId, bool value)
        {
            logger.Info($"SetCellCheckBox({rowId}, {columnId})");
            baseControl.SetCellCheckBox(rowId, columnId, value);
        }

        public virtual bool GetCellCheckBox(object rowId, object columnId)
        {
            logger.Info($"GetCellCheckBox({rowId}, {columnId})");
            return baseControl.GetCellCheckBox(rowId, columnId);
        }

        public virtual void SetCellRadioButton(object rowId, object columnId, bool value)
        {
            logger.Info($"SetCellRadioButton({rowId}, {columnId})");
            baseControl.SetCellRadioButton(rowId, columnId, value);
        }

        public virtual bool GetCellRadioButton(object rowId, object columnId)
        {
            logger.Info($"GetCellRadioButton({rowId}, {columnId})");
            return baseControl.GetCellRadioButton(rowId, columnId);
        }

        public virtual string GetCellText(object rowId, object columnId)
        {
            logger.Info($"GetCellText({rowId}, {columnId})");
            return baseControl.GetCellText(rowId, columnId);
        }

        public virtual string GetCellText(string cellText)
        {
            logger.Info($"GetCellText({cellText})");
            return baseControl.GetCellText(cellText);
        }

        public virtual void ClickContextMenu(object rowId, object columnId, string menuEntry)
        {
            logger.Info($"ClickContextMenu({rowId}, {columnId})");
            baseControl.ClickContextMenu(rowId, columnId, menuEntry);
        }
    }
}
