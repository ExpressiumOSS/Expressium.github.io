using OpenQA.Selenium;
using Expressium.Coffeeshop.Web.Controls;
using Expressium.Coffeeshop.Web.Models;
using System;
using System.Collections.Generic;
using log4net;

namespace Expressium.Coffeeshop.Web.Pages
{
    public partial class RegistrationPage : BasePage
    {
        private WebTextBox FirstName => new WebTextBox(driver, By.Name("firstname"));
        private WebTextBox LastName => new WebTextBox(driver, By.Name("lastname"));
        private WebComboBox Country => new WebComboBox(driver, By.Name("country"));
        private WebListBox Vehicle => new WebListBox(driver, By.Name("vehicle"));
        private WebTextBox Email => new WebTextBox(driver, By.Id("email"));
        private WebTextBox Phone => new WebTextBox(driver, By.Id("phone"));
        private WebRadioButton Male => new WebRadioButton(driver, By.Id("gender_0"));
        private WebRadioButton Female => new WebRadioButton(driver, By.Id("gender_1"));
        private WebTextBox Password => new WebTextBox(driver, By.Id("password"));
        private WebTextBox ConfirmPassword => new WebTextBox(driver, By.Id("password2"));
        private WebCheckBox IAgreeToTheTermsOfUse => new WebCheckBox(driver, By.Name("agreement"));
        private WebButton Submit => new WebButton(driver, By.XPath("//input[@type='button' and @value='Submit']"));
        private WebButton Reset => new WebButton(driver, By.XPath("//input[@type='reset' and @value='Reset']"));
        private WebButton Cancel => new WebButton(driver, By.XPath("//input[@type='button' and @value='Cancel']"));

        public RegistrationPage(ILog logger, IWebDriver driver) : base(logger, driver)
        {
            WaitForPageTitleEquals("Registration");
        }

        public void SetFirstName(string value)
        {
            logger.Info($"SetFirstName({value})");
            FirstName.SetText(value);
        }

        public string GetFirstName()
        {
            logger.Info("GetFirstName()");
            return FirstName.GetText();
        }

        public void SetLastName(string value)
        {
            logger.Info($"SetLastName({value})");
            LastName.SetText(value);
        }

        public string GetLastName()
        {
            logger.Info("GetLastName()");
            return LastName.GetText();
        }

        public void SetCountry(string value)
        {
            logger.Info($"SetCountry({value})");
            Country.SetText(value);
        }

        public string GetCountry()
        {
            logger.Info("GetCountry()");
            return Country.GetSelected();
        }

        public void SetVehicle(string value)
        {
            logger.Info($"SetVehicle({value})");
            Vehicle.SetText(value);
        }

        public string GetVehicle()
        {
            logger.Info("GetVehicle()");
            return Vehicle.GetSelected();
        }

        public void SetEmail(string value)
        {
            logger.Info($"SetEmail({value})");
            Email.SetText(value);
        }

        public string GetEmail()
        {
            logger.Info("GetEmail()");
            return Email.GetText();
        }

        public void SetPhone(string value)
        {
            logger.Info($"SetPhone({value})");
            Phone.SetText(value);
        }

        public string GetPhone()
        {
            logger.Info("GetPhone()");
            return Phone.GetText();
        }

        public void SetMale(bool value)
        {
            logger.Info($"SetMale({value})");
            Male.SetSelected(value);
        }

        public bool GetMale()
        {
            logger.Info("GetMale()");
            return Male.GetSelected();
        }

        public void SetFemale(bool value)
        {
            logger.Info($"SetFemale({value})");
            Female.SetSelected(value);
        }

        public bool GetFemale()
        {
            logger.Info("GetFemale()");
            return Female.GetSelected();
        }

        public void SetPassword(string value)
        {
            logger.Info($"SetPassword({value})");
            Password.SetText(value);
        }

        public string GetPassword()
        {
            logger.Info("GetPassword()");
            return Password.GetText();
        }

        public void SetConfirmPassword(string value)
        {
            logger.Info($"SetConfirmPassword({value})");
            ConfirmPassword.SetText(value);
        }

        public string GetConfirmPassword()
        {
            logger.Info("GetConfirmPassword()");
            return ConfirmPassword.GetText();
        }

        public void SetIAgreeToTheTermsOfUse(bool value)
        {
            logger.Info($"SetIAgreeToTheTermsOfUse({value})");
            IAgreeToTheTermsOfUse.SetChecked(value);
        }

        public bool GetIAgreeToTheTermsOfUse()
        {
            logger.Info("GetIAgreeToTheTermsOfUse()");
            return IAgreeToTheTermsOfUse.GetChecked();
        }

        public void ClickSubmit()
        {
            logger.Info($"ClickSubmit()");
            Submit.Click();
        }

        public void ClickReset()
        {
            logger.Info($"ClickReset()");
            Reset.Click();
        }

        public void ClickCancel()
        {
            logger.Info($"ClickCancel()");
            Cancel.Click();
        }

        public void FillForm(RegistrationPageModel model)
        {
            SetFirstName(model.FirstName);
            SetLastName(model.LastName);
            SetCountry(model.Country);
            SetVehicle(model.Vehicle);
            SetEmail(model.Email);
            SetPhone(model.Phone);
            SetMale(model.Male);
            SetFemale(model.Female);
            SetPassword(model.Password);
            SetConfirmPassword(model.ConfirmPassword);
            SetIAgreeToTheTermsOfUse(model.IAgreeToTheTermsOfUse);
        }

        #region Extensions

        #endregion
    }
}
