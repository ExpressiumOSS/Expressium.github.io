using OpenQA.Selenium;
using Expressium.Coffeeshop.Web.Controls;
using System;
using System.Collections.Generic;
using log4net;

namespace Expressium.Coffeeshop.Web.Pages
{
    public partial class LoginPage : BasePage
    {
        private WebTextBox Username => new WebTextBox(driver, By.Name("username"));
        private WebTextBox Password => new WebTextBox(driver, By.Name("password"));
        private WebButton LogIn => new WebButton(driver, By.ClassName("login"));
        private WebLink CreateAnAccount => new WebLink(driver, By.XPath("//a[normalize-space()='Create an account']"));
        private WebText Notification => new WebText(driver, By.Id("notification"));

        public LoginPage(ILog logger, IWebDriver driver) : base(logger, driver)
        {
            WaitForPageTitleEquals("Login");
        }

        public void SetUsername(string value)
        {
            logger.Info($"SetUsername({value})");
            Username.SetText(value);
        }

        public string GetUsername()
        {
            logger.Info("GetUsername()");
            return Username.GetText();
        }

        public void SetPassword(string value)
        {
            logger.Info($"SetPassword({value})");
            Password.SetText(value);
        }

        public string GetPassword()
        {
            logger.Info("GetPassword()");
            return Password.GetText();
        }

        public void ClickLogIn()
        {
            logger.Info($"ClickLogIn()");
            LogIn.Click();
        }

        public void ClickCreateAnAccount()
        {
            logger.Info($"ClickCreateAnAccount()");
            CreateAnAccount.Click();
        }

        public string GetNotification()
        {
            logger.Info("GetNotification()");
            return Notification.GetText();
        }

        #region Extensions

        #endregion
    }
}
