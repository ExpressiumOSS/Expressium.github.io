using log4net;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using Expressium.Coffeeshop.Web.Controls;

namespace Expressium.Coffeeshop.Web.Pages
{
    public class BasePage
    {
        protected readonly ILog logger;
        protected readonly IWebDriver driver;

        public static int PageTimeout { get; set; }

        public static By PageSpinnerLocator { get; set; }
        public static int PageSpinnerInitialTimeout { get; set; }
        public static int PageSpinnerTimeout { get; set; }

        static BasePage()
        {
            PageTimeout = 10000;

            PageSpinnerLocator = null;
            PageSpinnerInitialTimeout = 150;
            PageSpinnerTimeout = 10000;
        }

        public BasePage(ILog logger, IWebDriver driver)
        {
            this.logger = logger;
            this.driver = driver;

            WaitForPageDocumentReadyStateEqualsComplete();
            WaitForPageSpinnerIsCompleted();
        }

        public string GetTitle()
        {
            logger.Info("GetTitle()");
            return driver.Title;
        }

        public string GetURL()
        {
            logger.Info("GetURL()");
            return new Uri(driver.Url).LocalPath;
        }

        protected void WaitForPageDocumentReadyStateEqualsComplete()
        {
            try
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(PageTimeout));
                wait.Until(d => ((IJavaScriptExecutor)d).ExecuteScript("return document.readyState").Equals("complete"));
            }
            catch
            {
                throw new ApplicationException($"Page document ready state was expected to be completed within {PageTimeout} milliseconds...");
            }
        }

        protected void WaitForPageSpinnerIsCompleted()
        {
            if (PageSpinnerLocator != null)
            {
                var control = new WebControl(driver, PageSpinnerLocator);
                control.WaitForElementIsInvisible(PageSpinnerInitialTimeout, PageSpinnerTimeout);
            }
        }

        protected void WaitForPageTitleEquals(string title)
        {
            try
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(PageTimeout));
                wait.Until(d => d.Title.Equals(title));
            }
            catch
            {
                throw new ApplicationException($"Page title was expected to be equal to '{title}' but was '{driver.Title}' within {PageTimeout} milliseconds...");
            }
        }

        protected void WaitForPageTitleContains(string title)
        {
            try
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(PageTimeout));
                wait.Until(d => d.Title.Contains(title));
            }
            catch
            {
                throw new ApplicationException($"Page title was expected to contain '{title}' but was '{driver.Title}' within {PageTimeout} milliseconds...");
            }
        }

        protected void WaitForPageUrlEquals(string url)
        {
            try
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(PageTimeout));
                wait.Until(d => new Uri(d.Url).LocalPath.Equals(url));
            }
            catch
            {
                throw new ApplicationException($"Page URL was expected to be equal to '{url}' but was '{new Uri(driver.Url).LocalPath}' within {PageTimeout} milliseconds...");
            }
        }

        protected void WaitForPageUrlContains(string url)
        {
            try
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(PageTimeout));
                wait.Until(d => new Uri(d.Url).LocalPath.Contains(url));
            }
            catch
            {
                throw new ApplicationException($"Page URL was expected to contain '{url}' but was '{new Uri(driver.Url).LocalPath}' within {PageTimeout} milliseconds...");
            }
        }

        protected void WaitForPageElementIsVisible(WebControl control)
        {
            control.WaitForElementIsVisible();
        }

        protected void WaitForPageElementIsEnabled(WebControl control)
        {
            control.WaitForElementIsEnabled();
        }

        public void NavigateBack()
        {
            logger.Info("NavigateBack()");
            driver.Navigate().Back();
        }

        public void NavigateForward()
        {
            logger.Info("NavigateForward()");
            driver.Navigate().Forward();
        }

        public void NavigateRefresh()
        {
            logger.Info("NavigateRefresh()");
            driver.Navigate().Refresh();
        }

        public void ScrollToTop()
        {
            logger.Info("ScrollToTop()");
            ((IJavaScriptExecutor)driver).ExecuteScript("window.scrollTo(0, 0);");
        }

        public void ScrollToBottom()
        {
            logger.Info("ScrollToBottom()");
            ((IJavaScriptExecutor)driver).ExecuteScript("window.scrollTo(0, document.body.scrollHeight);");
        }

        public void SwitchToAlertAccept()
        {
            logger.Info("SwitchToAlertAccept()");
            driver.SwitchTo().Alert().Accept();
        }

        public void SwitchToAlertDismiss()
        {
            logger.Info("SwitchToAlertDismiss()");
            driver.SwitchTo().Alert().Dismiss();
        }

        protected int GetNumberOfBrowserTabs()
        {
            var value = driver.WindowHandles.Count;
            logger.Info($"GetNumberOfBrowserTabs() [{value}]");
            return value;
        }

        protected void WaitForNewBrowserTabIsOpened(int numberOfCurrentTabs)
        {
            try
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(PageTimeout));
                wait.Until(d => d.WindowHandles.Count > numberOfCurrentTabs);
            }
            catch
            {
                throw new ApplicationException($"WaitForNewBrowserTabIsOpened() has Failed - Expected {numberOfCurrentTabs + 1}, Found {driver.WindowHandles.Count}");
            }
        }

        protected void SelectBrowserTab(int index)
        {
            driver.SwitchTo().Window(driver.WindowHandles[index]);
        }
    }
}
