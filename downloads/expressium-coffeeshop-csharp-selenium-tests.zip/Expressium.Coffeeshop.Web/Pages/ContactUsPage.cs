using OpenQA.Selenium;
using Expressium.Coffeeshop.Web.Controls;
using System;
using System.Collections.Generic;
using log4net;

namespace Expressium.Coffeeshop.Web.Pages
{
    public partial class ContactUsPage : BasePage
    {
        private WebControl Heading => new WebControl(driver, By.XPath("//h1[text()]"));
        private WebTextBox Name => new WebTextBox(driver, By.Name("your-name"));
        private WebTextBox Email => new WebTextBox(driver, By.Name("your-email"));
        private WebTextBox Subject => new WebTextBox(driver, By.Name("your-subject"));
        private WebTextBox Message => new WebTextBox(driver, By.Name("your-message"));
        private WebButton Send => new WebButton(driver, By.XPath("//input[@type='button' and @value='Send']"));
        private WebText Notification => new WebText(driver, By.Id("notification"));

        public ContactUsPage(ILog logger, IWebDriver driver) : base(logger, driver)
        {
            WaitForPageTitleEquals("Contact Us");
            WaitForPageElementIsVisible(Heading);
        }

        public void SetName(string value)
        {
            logger.Info($"SetName({value})");
            Name.SetText(value);
        }

        public string GetName()
        {
            logger.Info("GetName()");
            return Name.GetText();
        }

        public void SetEmail(string value)
        {
            logger.Info($"SetEmail({value})");
            Email.SetText(value);
        }

        public string GetEmail()
        {
            logger.Info("GetEmail()");
            return Email.GetText();
        }

        public void SetSubject(string value)
        {
            logger.Info($"SetSubject({value})");
            Subject.SetText(value);
        }

        public string GetSubject()
        {
            logger.Info("GetSubject()");
            return Subject.GetText();
        }

        public void SetMessage(string value)
        {
            logger.Info($"SetMessage({value})");
            Message.SetText(value);
        }

        public string GetMessage()
        {
            logger.Info("GetMessage()");
            return Message.GetText();
        }

        public void ClickSend()
        {
            logger.Info($"ClickSend()");
            Send.Click();
        }

        public string GetNotification()
        {
            logger.Info("GetNotification()");
            return Notification.GetText();
        }

        #region Extensions

        #endregion
    }
}
