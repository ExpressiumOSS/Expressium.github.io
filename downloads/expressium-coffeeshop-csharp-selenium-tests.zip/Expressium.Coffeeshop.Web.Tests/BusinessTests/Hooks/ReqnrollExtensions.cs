using Reqnroll;

namespace Expressium.Coffeeshop.Web.Tests.BusinessTests.Hooks
{
    internal static class ReqnrollExtensions
    {
        internal static void AddAttachmentAsLink(this IReqnrollOutputHelper outputHelper, string path)
        {
            outputHelper.WriteLine($"[Attachment: {path}]");
        }
    }
}
