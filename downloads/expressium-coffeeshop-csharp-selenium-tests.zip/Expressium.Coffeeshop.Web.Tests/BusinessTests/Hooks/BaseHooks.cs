using Expressium.Coffeeshop.Web.Tests.BusinessTests.Steps;
using Expressium.Coffeeshop.Web.Tests.Infrastructure;
using Reqnroll;
using Reqnroll.BoDi;
using System.IO;
using System.Text.RegularExpressions;

namespace Expressium.Coffeeshop.Web.Tests.BusinessTests.Hooks
{
    [Binding]
    public class BaseHooks : BaseTestFixture
    {
        private readonly FeatureContext featureContext;
        private readonly ScenarioContext scenarioContext;
        private readonly IReqnrollOutputHelper reqnrollOutputHelper;
        private readonly IObjectContainer objectContainer;

        private BaseContext baseContext;

        public BaseHooks(FeatureContext featureContext, ScenarioContext scenarioContext, IReqnrollOutputHelper reqnrollOutputHelper, IObjectContainer objectContainer)
        {
            this.featureContext = featureContext;
            this.scenarioContext = scenarioContext;
            this.reqnrollOutputHelper = reqnrollOutputHelper;
            this.objectContainer = objectContainer;
        }

        [BeforeScenario]
        public void BeforeScenario()
        {
            InitializeFixture();

            baseContext = new BaseContext();
            baseContext.Configuration = configuration;
            baseContext.Logger = logger;
            baseContext.Asserts = asserts;
            baseContext.BrowserManager = browserManager;

            objectContainer.RegisterInstanceAs(baseContext);
        }

        [AfterScenario]
        public void AfterScenario()
        {
            FinalizeFixture();

            if (configuration.Loggings)
            {
                var fileName = Path.Combine(Folders.Loggings.ToString(), GetTestName() + ".log");
                reqnrollOutputHelper.AddAttachmentAsLink(fileName);
            }

            if (configuration.Screenshots)
            {
                var fileName = Path.Combine(Folders.Screenshots.ToString(), GetTestName() + ".png");
                reqnrollOutputHelper.AddAttachmentAsLink(fileName);
            }
        }

        [BeforeStep]
        public void BeforeStep()
        {
            logger.Info("");
            logger.Info($"// {scenarioContext.StepContext.StepInfo.StepDefinitionType} {scenarioContext.StepContext.StepInfo.Text}");
        }

        protected override string GetTestName()
        {
            var name = scenarioContext.ScenarioInfo.Title;

            if (scenarioContext.ScenarioInfo.Arguments.Count > 0)
            {
                var arguments = scenarioContext.ScenarioInfo.Arguments.Values;
                foreach (var argument in arguments)
                    name += argument;
            }

            name = string.Join("", name.Split(Path.GetInvalidFileNameChars()));
            return Regex.Replace(name, @"^\w| \w", (match) => match.Value.Replace(" ", "").ToUpper());
        }

        protected override string GetTestCategory()
        {
            return featureContext.FeatureInfo.Title;
        }

        protected override string GetTestDescription()
        {
            var name = scenarioContext.ScenarioInfo.Title;

            if (scenarioContext.ScenarioInfo.Arguments.Count > 0)
            {
                var arguments = scenarioContext.ScenarioInfo.Arguments.Values;
                foreach (var argument in arguments)
                    name += " " + argument;
            }

            return name;
        }
    }
}
