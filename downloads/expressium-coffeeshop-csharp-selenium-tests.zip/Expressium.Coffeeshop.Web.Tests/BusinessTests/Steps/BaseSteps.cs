using log4net;
using OpenQA.Selenium;
using Expressium.Coffeeshop.Web.Tests.Infrastructure;

namespace Expressium.Coffeeshop.Web.Tests.BusinessTests.Steps
{
    public class BaseSteps
    {
        protected readonly Configuration configuration;
        protected readonly ILog logger;
        protected readonly BrowserManager browserManager;
        protected readonly Asserts asserts;

        protected IWebDriver driver => browserManager.Driver;

        public BaseSteps(BaseContext baseContext)
        {
            configuration = baseContext.Configuration;
            logger = baseContext.Logger;
            browserManager = baseContext.BrowserManager;
            asserts = baseContext.Asserts;
        }
    }
}
