using Expressium.Coffeeshop.Web.Models;
using Expressium.Coffeeshop.Web.Pages;
using Expressium.Coffeeshop.Web.Tests.Factories;
using Reqnroll;

namespace Expressium.Coffeeshop.Web.Tests.BusinessTests.Steps
{
    [Binding]
    public class LoginSteps : BaseSteps
    {
        public LoginSteps(BaseContext baseContext) : base(baseContext)
        {
        }

        [Given(@"I have logged in with valid user credentials")]
        public void GivenIHaveLoggedInWithValidUserCredentials()
        {
            var loginPage = new LoginPage(logger, driver);
            loginPage.SetUsername(configuration.Username);
            loginPage.SetPassword(configuration.Password);
            loginPage.ClickLogIn();
        }

        [Then(@"I should be redirected to the Home page")]
        public void ThenIShouldBeRedirectedToTheHomePage()
        {
            var homePage = new HomePage(logger, driver);
            asserts.EqualTo(homePage.GetTitle(), "Home", "Validate the HomePage title property...");
        }

        [Given(@"I have logged in with invalid user credentials")]
        public void GivenIHaveLoggedInWithInvalidUserCredentials()
        {
            var loginPage = new LoginPage(logger, driver);
            loginPage.SetUsername("");
            loginPage.SetPassword(configuration.Password);
            loginPage.ClickLogIn();
        }

        [Then(@"I should have an error message displayed on the Login page")]
        public void ThenIShouldHaveAnErrorMessageDisplayedOnTheLoginPage()
        {
            var loginPage = new LoginPage(logger, driver);
            asserts.EqualTo(loginPage.GetTitle(), "Login", "Validate the LoginPage title property...");

            var expected = "Invalid Username or Password";
            asserts.EqualTo(loginPage.GetNotification(), expected, "Validate LoginPage notification message...");
        }

        [Then("I should be redirected to the Login page")]
        public void ThenIShouldBeRedirectedToTheLoginPage()
        {
            var loginPage = new LoginPage(logger, driver);
            asserts.EqualTo(loginPage.GetTitle(), "Home", "Validate the LoginPage title property...");
        }
    }
}
