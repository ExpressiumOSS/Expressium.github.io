using log4net;
using Expressium.Coffeeshop.Web.Tests.Infrastructure;

namespace Expressium.Coffeeshop.Web.Tests.BusinessTests.Steps
{
    public class BaseContext
    {
        public Configuration Configuration { get; set; }
        public ILog Logger { get; set; }
        public BrowserManager BrowserManager { get; set; }
        public Asserts Asserts {  get; set; }
    }
}
