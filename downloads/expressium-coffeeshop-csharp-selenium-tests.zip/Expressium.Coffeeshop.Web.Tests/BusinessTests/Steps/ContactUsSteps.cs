using Expressium.Coffeeshop.Web.Pages;
using Reqnroll;

namespace Expressium.Coffeeshop.Web.Tests.BusinessTests.Steps
{
    [Binding]
    public class ContactUsSteps : BaseSteps
    {
        public ContactUsSteps(BaseContext baseContext) : base(baseContext)
        {
        }
        
        [When(@"I complete and submit a valid Contact Us formular")]
        public void WhenICompleteAndSubmitAValidContactUsFormular()
        {
            var mainMenuBar = new MainMenuBar(logger, driver);
            mainMenuBar.ClickContactUs();

            var contactUsPage = new ContactUsPage(logger, driver);
            contactUsPage.SetName("John Doe");
            contactUsPage.SetEmail("john.doe@microsoft.com");
            contactUsPage.SetSubject("Detailed product information");
            contactUsPage.SetMessage("Please send some more detailed product information...");
            contactUsPage.ClickSend();
        }

        [Then(@"I should have a confirmation message displayed on the Contact Us page")]
        public void ThenIShouldHaveAConfirmationMessageDisplayedOnTheContactUsPage()
        {
            var contactUsPage = new ContactUsPage(logger, driver);

            var expected = "Your contact information has been send - Thanks...";
            asserts.EqualTo(contactUsPage.GetNotification(), expected, "Validate ContactUsPage notification message...");
        }
    }
}
