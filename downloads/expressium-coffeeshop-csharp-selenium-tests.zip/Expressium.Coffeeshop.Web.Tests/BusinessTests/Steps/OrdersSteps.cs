using Expressium.Coffeeshop.Web.Pages;
using Expressium.Coffeeshop.Web.Tests.Factories;
using Reqnroll;

namespace Expressium.Coffeeshop.Web.Tests.BusinessTests.Steps
{
    [Binding]
    public class OrdersSteps : BaseSteps
    {
        public OrdersSteps(BaseContext baseContext) : base(baseContext)
        {
        }

        [When(@"I add (.*) coffee to the shopping cart")]
        public void WhenIAddCoffeeToTheShoppingCart(string brand)
        {
            var mainMenuBar = new MainMenuBar(logger, driver);
            mainMenuBar.ClickProducts();

            var productsPage = new ProductsPage(logger, driver);
            productsPage.Grid.ClickCell(brand, 6);
        }

        [Then(@"I should have (.*) in the confirmation notification message")]
        public void ThenIShouldHavePriceInTheConfirmationNotificationMessage(string price)
        {
            var productsPage = new ProductsPage(logger, driver);
            asserts.DoesContain(productsPage.GetNotification(), price, "Validating the ProductsPage Price notification...");
        }

        [When("I add multiple pieces of coffee to the shopping cart")]
        public void WhenIAddMultiplePiecesOfCoffeeToTheShoppingCart(DataTable dataTable)
        {
            var coffees = dataTable.CreateInstance<Coffees>();

            var mainMenuBar = new MainMenuBar(logger, driver);
            mainMenuBar.ClickProducts();

            for (int i = 0; i < coffees.Pieces; i++)
            {
                var productsPage = new ProductsPage(logger, driver);
                productsPage.Grid.ClickCell(coffees.Brand, 6);
            }
        }

        [Then("I should have a confirmation notification message")]
        public void ThenIShouldHaveAConfirmationNotificationMessage()
        {
            var productsPage = new ProductsPage(logger, driver);
            asserts.IsNotEmpty(productsPage.GetNotification(), "Validating the ProductsPage notification...");
        }

        private class Coffees
        {
            public string Brand { get; set; }
            public int Pieces { get; set; }
        }
    }
}
