@TC-1000 @Login @BusinessTests
Feature: Login
	As a User
	I want to login on the web application
	So that I can administrate my product orders

@TC-1001 @Done
Scenario: Successful User Login with Valid Credentials
	Given I have logged in with valid user credentials
	Then I should be redirected to the Home page

@TC-1002 @Done
Scenario: Unsuccessful User Login with Invalid Credentials
	Given I have logged in with invalid user credentials
	Then I should have an error message displayed on the Login page
