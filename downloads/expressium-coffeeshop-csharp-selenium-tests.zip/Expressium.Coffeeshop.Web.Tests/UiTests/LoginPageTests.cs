using NUnit.Framework;
using Expressium.Coffeeshop.Web.Pages;
using System;

namespace Expressium.Coffeeshop.Web.Tests.UiTests
{
    [Category("UiTests")]
    [Description("Validate Navigation & Content of LoginPage")]
    public class LoginPageTests : BasePageTest
    {
        private LoginPage loginPage;

        private string username = "q8JFJm";
        private string password = "a69CJt";

        [OneTimeSetUp]
        public void OneTimeSetUp()
        {
            InitializeBrowser();

            // TODO - Implement potential missing page navigations...

            loginPage = new LoginPage(logger, driver);
            loginPage.SetUsername(username);
            loginPage.SetPassword(password);
        }

        [Test]
        public void Validate_Page_Title()
        {
            asserts.EqualTo(loginPage.GetTitle(), "Login", "Validating the LoginPage Title...");
        }

        [Test]
        public void Validate_Page_Property_Username()
        {
            asserts.EqualTo(loginPage.GetUsername(), username, "Validating the LoginPage property Username...");
        }

        [Test]
        public void Validate_Page_Property_Password()
        {
            asserts.EqualTo(loginPage.GetPassword(), password, "Validating the LoginPage property Password...");
        }
    }
}
