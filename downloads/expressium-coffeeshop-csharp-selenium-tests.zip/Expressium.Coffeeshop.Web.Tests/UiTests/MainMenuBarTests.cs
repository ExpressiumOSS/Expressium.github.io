using NUnit.Framework;
using Expressium.Coffeeshop.Web.Pages;
using System;

namespace Expressium.Coffeeshop.Web.Tests.UiTests
{
    [Category("UiTests")]
    [Description("Validate Navigation & Content of MainMenuBar")]
    public class MainMenuBarTests : BasePageTest
    {
        private MainMenuBar mainMenuBar;

        [OneTimeSetUp]
        public void OneTimeSetUp()
        {
            InitializeBrowserWithLogin();

            // TODO - Implement potential missing page navigations...

            mainMenuBar = new MainMenuBar(logger, driver);
        }

        [Test]
        public void Validate_Page_Title()
        {
            asserts.EqualTo(mainMenuBar.GetTitle(), "Home", "Validating the MainMenuBar Title...");
        }
    }
}
