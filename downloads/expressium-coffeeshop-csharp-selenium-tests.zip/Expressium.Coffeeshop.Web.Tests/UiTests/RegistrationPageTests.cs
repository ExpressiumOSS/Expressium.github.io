using NUnit.Framework;
using Expressium.Coffeeshop.Web.Models;
using Expressium.Coffeeshop.Web.Pages;
using Expressium.Coffeeshop.Web.Tests.Factories;
using System;

namespace Expressium.Coffeeshop.Web.Tests.UiTests
{
    [Category("UiTests")]
    [Description("Validate Navigation & Content of RegistrationPage")]
    public class RegistrationPageTests : BasePageTest
    {
        private RegistrationPage registrationPage;
        private RegistrationPageModel registrationPageModel = RegistrationPageFactory.Default();

        [OneTimeSetUp]
        public void OneTimeSetUp()
        {
            InitializeBrowser();

            // TODO - Implement potential missing page navigations...

            var loginPage = new LoginPage(logger, driver);
            loginPage.ClickCreateAnAccount();

            registrationPage = new RegistrationPage(logger, driver);
            registrationPage.FillForm(registrationPageModel);
        }

        [Test]
        public void Validate_Page_Title()
        {
            asserts.EqualTo(registrationPage.GetTitle(), "Registration", "Validating the RegistrationPage Title...");
        }

        [Test]
        public void Validate_Page_Property_FirstName()
        {
            asserts.EqualTo(registrationPage.GetFirstName(), registrationPageModel.FirstName, "Validating the RegistrationPage property FirstName...");
        }

        [Test]
        public void Validate_Page_Property_LastName()
        {
            asserts.EqualTo(registrationPage.GetLastName(), registrationPageModel.LastName, "Validating the RegistrationPage property LastName...");
        }

        [Test]
        public void Validate_Page_Property_Country()
        {
            asserts.EqualTo(registrationPage.GetCountry(), registrationPageModel.Country, "Validating the RegistrationPage property Country...");
        }

        [Test]
        public void Validate_Page_Property_Vehicle()
        {
            asserts.EqualTo(registrationPage.GetVehicle(), registrationPageModel.Vehicle, "Validating the RegistrationPage property Vehicle...");
        }

        [Test]
        public void Validate_Page_Property_Email()
        {
            asserts.EqualTo(registrationPage.GetEmail(), registrationPageModel.Email, "Validating the RegistrationPage property Email...");
        }

        [Test]
        public void Validate_Page_Property_Phone()
        {
            asserts.EqualTo(registrationPage.GetPhone(), registrationPageModel.Phone, "Validating the RegistrationPage property Phone...");
        }

        [Test]
        public void Validate_Page_Property_Male()
        {
            asserts.EqualTo(registrationPage.GetMale(), registrationPageModel.Male, "Validating the RegistrationPage property Male...");
        }

        [Test]
        public void Validate_Page_Property_Female()
        {
            asserts.EqualTo(registrationPage.GetFemale(), registrationPageModel.Female, "Validating the RegistrationPage property Female...");
        }

        [Test]
        public void Validate_Page_Property_Password()
        {
            asserts.EqualTo(registrationPage.GetPassword(), registrationPageModel.Password, "Validating the RegistrationPage property Password...");
        }

        [Test]
        public void Validate_Page_Property_ConfirmPassword()
        {
            asserts.EqualTo(registrationPage.GetConfirmPassword(), registrationPageModel.ConfirmPassword, "Validating the RegistrationPage property ConfirmPassword...");
        }

        [Test]
        public void Validate_Page_Property_IAgreeToTheTermsOfUse()
        {
            asserts.EqualTo(registrationPage.GetIAgreeToTheTermsOfUse(), registrationPageModel.IAgreeToTheTermsOfUse, "Validating the RegistrationPage property IAgreeToTheTermsOfUse...");
        }
    }
}
