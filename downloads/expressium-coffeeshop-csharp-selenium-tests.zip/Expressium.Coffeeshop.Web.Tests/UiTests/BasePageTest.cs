using NUnit.Framework;
using Expressium.Coffeeshop.Web.Pages;
using Expressium.Coffeeshop.Web.Tests.Infrastructure;

namespace Expressium.Coffeeshop.Web.Tests.UiTests
{
    public class BasePageTest : BaseTestFixture
    {
        [OneTimeSetUp]
        protected void InitializeTestcase()
        {
            logger.Info("");
            logger.Info("// Initialize Testcase");
        }

        public void InitializeBrowser()
        {
        }

        public void InitializeBrowserWithLogin()
        {
            InitializeBrowser();

            var loginPage = new LoginPage(logger, driver);
            loginPage.SetUsername(configuration.Username);
            loginPage.SetPassword(configuration.Password);
            loginPage.ClickLogIn();
        }
    }
}
