using NUnit.Framework;
using Expressium.Coffeeshop.Web.Pages;
using System;

namespace Expressium.Coffeeshop.Web.Tests.UiTests
{
    [Category("UiTests")]
    [Description("Validate Navigation & Content of HomePage")]
    public class HomePageTests : BasePageTest
    {
        private HomePage homePage;

        [OneTimeSetUp]
        public void OneTimeSetUp()
        {
            InitializeBrowserWithLogin();

            // TODO - Implement potential missing page navigations...

            var mainMenuBar = new MainMenuBar(logger, driver);
            mainMenuBar.ClickHome();

            homePage = new HomePage(logger, driver);
        }

        [Test]
        public void Validate_Page_Title()
        {
            asserts.EqualTo(homePage.GetTitle(), "Home", "Validating the HomePage Title...");
        }
    }
}
