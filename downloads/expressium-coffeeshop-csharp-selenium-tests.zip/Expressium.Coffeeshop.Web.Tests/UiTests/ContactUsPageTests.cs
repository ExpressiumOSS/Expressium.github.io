using NUnit.Framework;
using Expressium.Coffeeshop.Web.Pages;
using System;

namespace Expressium.Coffeeshop.Web.Tests.UiTests
{
    [Category("UiTests")]
    [Description("Validate Navigation & Content of ContactUsPage")]
    public class ContactUsPageTests : BasePageTest
    {
        private ContactUsPage contactUsPage;

        private string name = "Peter Parker";
        private string email = "peter.parker@expressium.dev";
        private string subject = "Detailed Information";
        private string message = "Please send some detailed product information...";

        [OneTimeSetUp]
        public void OneTimeSetUp()
        {
            InitializeBrowserWithLogin();

            // TODO - Implement potential missing page navigations...

            var mainMenuBar = new MainMenuBar(logger, driver);
            mainMenuBar.ClickContactUs();

            contactUsPage = new ContactUsPage(logger, driver);
            contactUsPage.SetName(name);
            contactUsPage.SetEmail(email);
            contactUsPage.SetSubject(subject);
            contactUsPage.SetMessage(message);
        }

        [Test]
        public void Validate_Page_Title()
        {
            asserts.EqualTo(contactUsPage.GetTitle(), "Contact Us", "Validating the ContactUsPage Title...");
        }

        [Test]
        public void Validate_Page_Property_Name()
        {
            asserts.EqualTo(contactUsPage.GetName(), name, "Validating the ContactUsPage property Name...");
        }

        [Test]
        public void Validate_Page_Property_Email()
        {
            asserts.EqualTo(contactUsPage.GetEmail(), email, "Validating the ContactUsPage property Email...");
        }

        [Test]
        public void Validate_Page_Property_Subject()
        {
            asserts.EqualTo(contactUsPage.GetSubject(), subject, "Validating the ContactUsPage property Subject...");
        }

        [Test]
        public void Validate_Page_Property_Message()
        {
            asserts.EqualTo(contactUsPage.GetMessage(), message, "Validating the ContactUsPage property Message...");
        }
    }
}
