using log4net;
using log4net.Appender;
using log4net.Config;
using log4net.Core;
using log4net.Layout;
using log4net.Layout.Pattern;
using System;
using System.IO;

namespace Expressium.Coffeeshop.Web.Tests.Infrastructure
{
    public class Logger
    {
        public static ILog Initialize(string name, string filePath = null)
        {
            var repositoryName = $"{name}-{Guid.NewGuid():N}";
            var repository = LoggerManager.CreateRepository(repositoryName);

            var patternLayout = new PatternLayout();
            patternLayout.AddConverter("shortType", typeof(ShortTypePatternConverter));
            patternLayout.ConversionPattern = "%date{HH:mm:ss} %level %shortType # %message%newline";
            patternLayout.ActivateOptions();

            var consoleAppender = new ConsoleAppender();
            consoleAppender.Layout = patternLayout;
            consoleAppender.Threshold = Level.All;
            consoleAppender.ActivateOptions();

            if (string.IsNullOrWhiteSpace(filePath))
            {
                BasicConfigurator.Configure(repository, consoleAppender);
            }
            else
            {
                var rollingFileAppender = new RollingFileAppender();
                rollingFileAppender.AppendToFile = false;
                rollingFileAppender.File = filePath;
                rollingFileAppender.Layout = patternLayout;
                rollingFileAppender.Threshold = Level.All;
                rollingFileAppender.MaxSizeRollBackups = 0;
                rollingFileAppender.MaximumFileSize = "1GB";
                rollingFileAppender.ActivateOptions();

                BasicConfigurator.Configure(repository, rollingFileAppender, consoleAppender);
            }

            return LogManager.GetLogger(repositoryName, name);
        }

        private class ShortTypePatternConverter : PatternLayoutConverter
        {
            protected override void Convert(TextWriter writer, LoggingEvent loggingEvent)
            {
                var className = loggingEvent.LocationInformation.ClassName;

                var plusIndex = className.IndexOf('+');
                if (plusIndex >= 0)
                    className = className.Substring(0, plusIndex);

                //var lastDotIndex = className.LastIndexOf('.');
                //if (lastDotIndex >= 0)
                //    className = className.Substring(lastDotIndex + 1);

                writer.Write(className);
            }
        }
    }
}
