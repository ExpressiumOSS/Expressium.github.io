using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Firefox;
using System;

namespace Expressium.Coffeeshop.Web.Tests.Infrastructure
{
    public enum BrowserTypes
    {
        Chrome,
        Firefox,
        Edge
    }

    public class BrowserFactory
    {
        public static IWebDriver Initialize(Configuration configuration)
        {
            if (!Enum.TryParse<BrowserTypes>(configuration.BrowserType, ignoreCase: true, out var browserType))
                throw new ArgumentException($"Specified browser type '{configuration.BrowserType}' is unknown...");

            switch (browserType)
            {
                case BrowserTypes.Chrome:
                    return InitializeChromeBrowser(configuration);
                case BrowserTypes.Firefox:
                    return InitializeFirefoxBrowser(configuration);
                case BrowserTypes.Edge:
                    return InitializeEdgeBrowser(configuration);
                default:
                    throw new ArgumentException($"Specified browser type '{configuration.BrowserType}' is unknown...");
            }
        }

        private static IWebDriver InitializeChromeBrowser(Configuration configuration)
        {
            var service = ChromeDriverService.CreateDefaultService();
            service.HideCommandPromptWindow = true;

            var options = new ChromeOptions();
            options.AddArgument("--disable-notifications");
            options.AddArgument("--disable-search-engine-choice-screen");
            options.AddExcludedArgument("enable-automation");
            options.AddUserProfilePreference("credentials_enable_service", false);
            options.AddUserProfilePreference("profile.password_manager_leak_detection", false);

            if (configuration.Maximize)
                options.AddArguments("start-maximized");

            if (configuration.Headless)
            {
                options.AddArgument("--headless");
                options.AddArgument($"--window-size={configuration.WindowWidth},{configuration.WindowHeight}");
            }
            else if (configuration.WindowSize)
            {
                options.AddArgument($"--window-size={configuration.WindowWidth},{configuration.WindowHeight}");
                options.AddArgument("--window-position=10,10");
            }

            var driver = new ChromeDriver(service, options);

            if (configuration.Url != null)
                driver.Navigate().GoToUrl(configuration.Url);

            return driver;
        }

        private static IWebDriver InitializeFirefoxBrowser(Configuration configuration)
        {
            var service = FirefoxDriverService.CreateDefaultService();
            service.HideCommandPromptWindow = true;
            // Required on some platforms where geckodriver only binds to IPv6 loopback
            service.Host = "::1";

            var options = new FirefoxOptions();

            if (configuration.Maximize)
                options.AddArguments("--start-maximized");

            if (configuration.Headless)
            {
                options.AddArguments("--headless");
                options.AddArgument($"--width={configuration.WindowWidth}");
                options.AddArgument($"--height={configuration.WindowHeight}");
            }
            else if (configuration.WindowSize)
            {
                options.AddArgument($"--width={configuration.WindowWidth}");
                options.AddArgument($"--height={configuration.WindowHeight}");
            }

            var driver = new FirefoxDriver(service, options);

            if (configuration.Url != null)
                driver.Navigate().GoToUrl(configuration.Url);

            return driver;
        }

        private static IWebDriver InitializeEdgeBrowser(Configuration configuration)
        {
            var service = EdgeDriverService.CreateDefaultService();
            service.HideCommandPromptWindow = true;

            var options = new EdgeOptions();
            options.AddArgument("--disable-notifications");
            options.AddExcludedArgument("enable-automation");
            options.AddUserProfilePreference("credentials_enable_service", false);

            if (configuration.Maximize)
                options.AddArguments("start-maximized");

            if (configuration.Headless)
            {
                options.AddArgument("--headless");
                options.AddArgument($"--window-size={configuration.WindowWidth},{configuration.WindowHeight}");
            }
            else if (configuration.WindowSize)
            {
                options.AddArgument($"--window-size={configuration.WindowWidth},{configuration.WindowHeight}");
                options.AddArgument("--window-position=10,10");
            }

            var driver = new EdgeDriver(service, options);

            if (configuration.Url != null)
                driver.Navigate().GoToUrl(configuration.Url);

            return driver;
        }
    }
}
