using log4net;
using NUnit.Framework;
using NUnit.Framework.Interfaces;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Expressium.Coffeeshop.Web.Controls;

namespace Expressium.Coffeeshop.Web.Tests.Infrastructure
{
    public class BaseTestFixture
    {
        protected readonly Configuration configuration;
        protected readonly BrowserManager browserManager;

        protected ILog logger;
        protected Asserts asserts;

        protected IWebDriver driver => browserManager.Driver;

        public BaseTestFixture()
        {
            configuration = ConfigurationLoader.GetConfiguration();
            browserManager = new BrowserManager(configuration);

            WebElements.Highlight = configuration.Highlight;
            WebElements.HighlightTimeout = configuration.HighlightTimeout;
        }

        [OneTimeSetUp]
        protected virtual void InitializeFixture()
        {
            if (configuration.Loggings)
            {
                var filePath = Path.Combine(configuration.LoggingsPath, GetTestName() + ".log");
                if (File.Exists(filePath))
                    File.Delete(filePath);

                logger = Logger.Initialize(GetTestName(), filePath);
                asserts = new Asserts(logger);
            }
            else
            {
                logger = Logger.Initialize(GetTestName());
                asserts = new Asserts(logger);
            }

            if (configuration.Screenshots)
            {
                var filePath = Path.Combine(configuration.ScreenshotsPath, GetTestName() + ".png");
                if (File.Exists(filePath))
                    File.Delete(filePath);
            }

            logger.Info("// Initialize Test Fixture");
            logger.Info($"Company: {configuration.Company}");
            logger.Info($"Project: {configuration.Project}");
            logger.Info($"Environment: {configuration.Environment}");
            logger.Info($"Name: {GetTestName()}");
            logger.Info($"Category: {GetTestCategory()}");
            logger.Info($"Description: {GetTestDescription()}");
            logger.Info($"Date: {DateTime.Now.ToString("dd-MM-yyyy HH:mm")}");
        }

        [OneTimeTearDown]
        protected virtual void FinalizeFixture()
        {
            logger.Info("");
            logger.Info("// Finalize Test Fixture");

            if (browserManager.HasDriver)
            {
                if (configuration.Screenshots)
                {
                    var filePath = Path.Combine(configuration.ScreenshotsPath, GetTestName() + ".png");
                    browserManager.SaveScreenshot(filePath);
                    logger.Info($"Screenshot has been saved: {Path.GetFileName(filePath)}");
                }

                browserManager.Quit();
            }

            LogMessageAsError(GetTestResultMessage());
            LogMessageAsDebug(GetTestResultStackTrace());

            logger.Info($"Number of passed tests: {GetTestPassCount()}");
            logger.Info($"Number of skipped tests: {GetTestSkipCount()}");
            logger.Info($"Number of inconclusive tests: {GetTestInconclusiveCount()}");
            logger.Info($"Number of failed tests: {GetTestFailCount()}");

            var status = GetTestStatus();
            string statusCode;

            if (status == TestStatus.Failed)
                statusCode = "Testcase has failed during execution...";
            else if (status == TestStatus.Inconclusive)
                statusCode = "Testcase was inconclusive executed...";
            else if (status == TestStatus.Skipped)
                statusCode = "Testcase was skipped from execution...";
            else
                statusCode = "Testcase was successfully executed...";

            logger.Info(statusCode + "\r\n");
            logger.Logger.Repository.Shutdown();
        }

        [SetUp]
        protected virtual void InitializeTest()
        {
            logger.Info("");
            logger.Info($"// {GetTestMethodName()}");
        }

        [TearDown]
        protected virtual void FinalizeTest()
        {
            if (GetTestStatus() == TestStatus.Failed)
            {
                LogMessageAsError(GetTestResultMessage());
                LogMessageAsDebug(GetTestResultStackTrace());
            }
        }

        protected virtual string GetTestName()
        {
            var name = TestContext.CurrentContext.Test.Name.Replace(" ", "");
            return string.Join("", name.Split(Path.GetInvalidFileNameChars()));
        }

        protected virtual string GetTestMethodName()
        {
            return TestContext.CurrentContext.Test.Name.Replace("_", " ");
        }

        protected virtual string GetTestCategory()
        {
            if (TestContext.CurrentContext.Test.Properties.Keys.Contains("Category"))
                return TestContext.CurrentContext.Test.Properties.Get("Category").ToString();

            return null;
        }

        protected virtual string GetTestDescription()
        {
            if (TestContext.CurrentContext.Test.Properties.Keys.Contains("Description"))
                return TestContext.CurrentContext.Test.Properties.Get("Description").ToString();

            return TestContext.CurrentContext.Test.Name;
        }

        protected virtual TestStatus GetTestStatus()
        {
            return TestContext.CurrentContext.Result.Outcome.Status;
        }

        protected virtual string GetTestResultMessage()
        {
            return TestContext.CurrentContext.Result.Message;
        }

        protected virtual string GetTestResultStackTrace()
        {
            return TestContext.CurrentContext.Result.StackTrace;
        }

        protected virtual int GetTestPassCount()
        {
            return TestContext.CurrentContext.Result.PassCount;
        }

        protected virtual int GetTestSkipCount()
        {
            return TestContext.CurrentContext.Result.SkipCount;
        }

        protected virtual int GetTestInconclusiveCount()
        {
            return TestContext.CurrentContext.Result.InconclusiveCount;
        }

        protected virtual int GetTestFailCount()
        {
            return TestContext.CurrentContext.Result.FailCount;
        }

        private void LogMessageAsError(string message)
        {
            try
            {
                if (message != null)
                {
                    var listOfLines = GetStringAsListOfLines(message);
                    foreach (var line in listOfLines)
                        logger.Error(line);
                }
            }
            catch (Exception exception)
            {
                logger.Error("LogMessageAsError has failed during execution...");
                logger.Debug(exception.Message);
            }
        }

        private void LogMessageAsDebug(string message)
        {
            try
            {
                if (message != null)
                {
                    var listOfLines = GetStringAsListOfLines(message);
                    foreach (var line in listOfLines)
                        logger.Debug(line);
                }
            }
            catch (Exception exception)
            {
                logger.Error("LogMessageAsDebug has failed during execution...");
                logger.Debug(exception.Message);
            }
        }

        private List<string> GetStringAsListOfLines(string message)
        {
            var listOfLines = new List<string>();

            char[] delimiterChars = { '\r', '\n' };
            var listOfTokens = message.Split(delimiterChars).ToList();
            foreach (var token in listOfTokens)
            {
                string text = token.Trim();
                if (!string.IsNullOrWhiteSpace(text))
                    listOfLines.Add(token);
            }

            return listOfLines;
        }
    }
}
