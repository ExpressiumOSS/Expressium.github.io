using System.IO;

namespace Expressium.Coffeeshop.Web.Tests.Infrastructure
{
    public enum Folders
    {
        Loggings,
        Screenshots
    }

    public class Configuration
    {
        public enum Profiles
        {
            Development,
            Test,
            PreProduction,
            Production
        }

        public string Company { get; set; }
        public string Project { get; set; }
        public string Environment { get; set; }
        public bool Loggings { get; set; }
        public string LoggingsPath { get { return Path.Combine(Directory.GetCurrentDirectory(), Folders.Loggings.ToString()); } }
        public bool Screenshots { get; set; }
        public string ScreenshotsPath { get { return Path.Combine(Directory.GetCurrentDirectory(), Folders.Screenshots.ToString()); } }
        public string Url { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string BrowserType { get; set; }
        public bool Maximize { get; set; }
        public bool Headless { get; set; }
        public bool WindowSize { get; set; }
        public int WindowWidth { get; set; }
        public int WindowHeight { get; set; }
        public bool Highlight { get; set; }
        public int HighlightTimeout { get; set; }
    }
}
