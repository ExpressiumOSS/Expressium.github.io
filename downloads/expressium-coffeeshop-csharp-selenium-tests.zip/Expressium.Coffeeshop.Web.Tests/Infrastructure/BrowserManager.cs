using OpenQA.Selenium;

namespace Expressium.Coffeeshop.Web.Tests.Infrastructure
{
    public class BrowserManager
    {
        private readonly Configuration configuration;
        private IWebDriver driver;

        public BrowserManager(Configuration configuration)
        {
            this.configuration = configuration;
        }

        public IWebDriver Driver
        {
            get
            {
                if (driver == null)
                    driver = BrowserFactory.Initialize(configuration);

                return driver;
            }
        }

        public bool HasDriver => driver != null;

        public void SaveScreenshot(string filePath)
        {
            if (driver is ITakesScreenshot screenshotDriver)
            {
                var screenshot = screenshotDriver.GetScreenshot();
                screenshot.SaveAsFile(filePath);
            }
        }

        public void Quit()
        {
            if (driver != null)
            {
                driver.Quit();
                driver = null;
            }
        }
    }
}
