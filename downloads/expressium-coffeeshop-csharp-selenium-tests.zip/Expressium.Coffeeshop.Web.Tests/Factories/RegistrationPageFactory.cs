using Expressium.Coffeeshop.Web.Models;
using System;

namespace Expressium.Coffeeshop.Web.Tests.Factories
{
    public class RegistrationPageFactory
    {
        public static RegistrationPageModel Default()
        {
            var model = new RegistrationPageModel();

            // TODO - Implement potential missing factory property...

            model.FirstName = "John";
            model.LastName = "Doe";
            model.Country = "Denmark";
            model.Vehicle = "Volvo";
            model.Email = "ePTBtq";
            model.Phone = "WYd04d";
            model.Male = false;
            model.Female = true;
            model.Password = "d2tKKa";
            model.ConfirmPassword = "5OXEH8";
            model.IAgreeToTheTermsOfUse = true;

            return model;
        }
    }
}
