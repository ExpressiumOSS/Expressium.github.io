using System;
using System.Linq;

namespace Expressium.Coffeeshop.Web.Tests.Factories
{
    public class Randomizer
    {
        public static string GetRandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            return new string(Enumerable.Repeat(chars, length).Select(s => s[Random.Shared.Next(s.Length)]).ToArray());
        }

        public static int GetRandomInteger(int minValue, int maxValue)
        {
            return Random.Shared.Next(minValue, maxValue);
        }

        public static string GetUniqueId()
        {
            return "ID" + DateTime.Now.ToString("yyyyMMddHHmmssff");
        }

        public static string GetDateTimeId()
        {
            return DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ssZ");
        }
    }
}
