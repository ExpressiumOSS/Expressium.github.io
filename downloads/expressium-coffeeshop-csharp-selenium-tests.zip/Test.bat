dotnet test
exit
