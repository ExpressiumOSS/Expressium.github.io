echo Runnning Regression Test...

set PROFILE=Development

rmdir /q /s .\Expressium.Coffeeshop.Web.Tests\bin\Debug\net10.0\TestResults

dotnet nuget
dotnet build

dotnet test .\Expressium.Coffeeshop.Web.Tests\Expressium.Coffeeshop.Web.Tests.csproj --filter TestCategory="UiTests"
dotnet test .\Expressium.Coffeeshop.Web.Tests\Expressium.Coffeeshop.Web.Tests.csproj --filter TestCategory="BusinessTests"
